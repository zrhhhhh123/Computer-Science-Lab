




 bool isLittleEndian(){
 	union a{
 		int i;
 		char c;
	 } u;
	 u.i=1;
	 if(u.c==1){
	 	return true;
	 }
	 else {
	 	return false;} 
 }
 	
 	
