
    #include <stdio.h>
#include <stdlib.h>
#include<assert.h>
int my_strlen(char* str)

{
	assert(str != NULL);

	int count = 0;

	while (*str != '\0')

	{
		count++;
		str++;
	}
	return count;

}
int main()
{
	char str[100];
	scanf("%s", str);
	float sum = 0;
	float count = 1.0;
	int n = my_strlen(str);
	int x = 0;
	int i = 0;
	for ( i = 0; i < n&&str[i]!='.'; i++) {
		x++;
	}
	for ( i = x - 1; i >= 0; i--) {

		if ((int)str[i] >= 48 && (int)str[i]<= 57)
		{
			sum += count * ((int)str[i] - 48);
			count *= 10;
		}
	}
	count = 0.1;
	for ( i = x + 1; i < n; i++) {

		if ((int)str[i] >= 48 && (int)str[i]<= 57)
		{
			sum += count * ((int)str[i] - 48);
			count /= 10;
		}
	}
	printf("%lf",sum);
}


