#include <stdio.h>
#include <stdlib.h>

unsigned int Fib(unsigned int n)
	{
	    if (n == 0)		return 0;
		if (n == 2||n==1)		return 1;
		unsigned int f1 = 1;	unsigned int f2 = 1;	unsigned int c = 0;
		for (unsigned int i = 3; i <= n; i++)
		{	c = f1 + f2;
			f1 = f2;
			f2 = c;
}
		return c;
	}
int main()
{
	unsigned int n = 0;
	unsigned int sum = 0;
	scanf_s("%d", &n);
	sum = Fib(n);
	printf("%d", sum);
	return 0;

}
