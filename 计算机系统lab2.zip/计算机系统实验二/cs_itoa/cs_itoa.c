#include <stdio.h>
#include <stdlib.h>
int main()
{
	int x;
	scanf("%d", &x);
	int y=x;
 	int n = 1;
 	while(y/10)
 {
 	y/=10;
 	++n;
 }

	char str[n];
	for (int i = n - 1; i >= 0; i--) {
		int m=x%10;
		x/=10;
		str[i] = m+48;
	}
	printf("%s", str);
}

