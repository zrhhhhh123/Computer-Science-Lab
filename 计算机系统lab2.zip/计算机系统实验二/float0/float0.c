#include <stdio.h>
#include <stdlib.h>
union tx{
		int a ;
		float b;}a1;
int main()
{
	float a=1.0;
	a1.a=1;
	printf("1.0/0:%f\n",a/0);
	printf("1.0/��С������:%f\n",a/a1.b);

 }
