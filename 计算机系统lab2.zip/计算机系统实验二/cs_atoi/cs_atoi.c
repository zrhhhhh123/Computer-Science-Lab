#include <stdio.h>
#include <stdlib.h>
#include<assert.h>
int my_strlen(char* str)

{

	assert(str != NULL);

	int count = 0;

	while (*str != '\0')

	{

		count++;

		str++;

	}

	return count;

}
int main()
{
	char a[80];
	scanf("%s", a);
	int b;
	int count = 1;
	int n = my_strlen(a);
	int sum = 0;
	for (int i = n - 1; i >= 0; i--) {
		b = (int)a[i];
		if (b >= 48 && b <= 57)
		{
			sum += count * (b - 48);
			count *= 10;
		}

	}
	printf("%d", sum);

}
